import subprocess
import argparse

def run_command(command, description):
    """Run a shell command and stream output in real-time."""
    print(f"\n🚀 Starting: {description}...\n")
    
    process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8", errors="replace")

    # Stream the output in real-time
    for line in iter(process.stdout.readline, ''):
        print(line, end="")  # Print each line as it arrives

    process.stdout.close()
    process.wait()

    # Capture and display any errors
    # stderr_output = process.stderr.read()
    # if stderr_output:
    #     print(f"\n❌ Error during {description}:\n{stderr_output}")

    print(f"\n✅ {description} completed!\n")

def main():
    # Argument parser for bounding box and ray-tracing parameters
    parser = argparse.ArgumentParser(description="Run OSM Extraction and Ray-Tracing Sequentially")
    parser.add_argument("--minlat", type=float, required=True)
    parser.add_argument("--minlon", type=float, required=True)
    parser.add_argument("--maxlat", type=float, required=True)
    parser.add_argument("--maxlon", type=float, required=True)
    parser.add_argument("--bs", type=str, required=True)
    
    # Carrier frequency and bandwidth
    parser.add_argument("--carrier_frequency", type=float, default=3.5e9, help="Carrier frequency in Hz")
    parser.add_argument("--bandwidth", type=float, default=10e6, help="Bandwidth in Hz")

    # Ray-tracing parameters
    parser.add_argument("--max_paths", type=int, default=25)
    parser.add_argument("--ray_spacing", type=float, default=0.25)
    parser.add_argument("--max_reflections", type=int, default=3)
    parser.add_argument("--max_transmissions", type=int, default=0)
    parser.add_argument("--max_diffractions", type=int, default=0)
    parser.add_argument("--ds_enable", action="store_true")
    parser.add_argument("--ds_max_reflections", type=int, default=2)
    parser.add_argument("--ds_max_diffractions", type=int, default=0)
    parser.add_argument("--ds_max_transmissions", type=int, default=0)
    parser.add_argument("--ds_final_interaction_only", action="store_true", default=True)

    args = parser.parse_args()

    # Step 1: Run OSM Extraction (Streams output in real-time)
    osm_command = [
        "python", "run_osm_extraction.py",
        "--minlat", str(args.minlat), "--minlon", str(args.minlon),
        "--maxlat", str(args.maxlat), "--maxlon", str(args.maxlon)
    ]
    run_command(osm_command, "OSM Extraction")

    # Step 2: Run Ray-Tracing (Streams output in real-time)
    raytrace_command = [
        "python", "raytrace_insite.py",
        "--minlat", str(args.minlat), "--minlon", str(args.minlon),
        "--maxlat", str(args.maxlat), "--maxlon", str(args.maxlon),
        "--bs", args.bs,
        "--carrier_frequency", str(args.carrier_frequency),
        "--bandwidth", str(args.bandwidth),
        "--max_paths", str(args.max_paths),
        "--ray_spacing", str(args.ray_spacing),
        "--max_reflections", str(args.max_reflections),
        "--max_transmissions", str(args.max_transmissions),
        "--max_diffractions", str(args.max_diffractions),
        "--ds_max_reflections", str(args.ds_max_reflections),
        "--ds_max_diffractions", str(args.ds_max_diffractions),
        "--ds_max_transmissions", str(args.ds_max_transmissions),
    ]
    
    if args.ds_enable:
        raytrace_command.append("--ds_enable")
    if args.ds_final_interaction_only:
        raytrace_command.append("--ds_final_interaction_only")

    run_command(raytrace_command, "Ray-Tracing Simulation")

if __name__ == "__main__":
    main()
